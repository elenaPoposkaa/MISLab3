import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import '../widgets/joke_type_grid.dart';
import '../widgets/auth_guard.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<String> jokeTypes = [];

  @override
  void initState() {
    super.initState();
    getJokeTypes();
  }

  void getJokeTypes() async {
    ApiService.getJokeTypes().then((response) {
      setState(() {
        jokeTypes = response;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return AuthGuard(
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Joke App", style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.green,
          actions: [
            IconButton(
              icon: const Icon(Icons.favorite, color: Colors.white),
              onPressed: () => Navigator.pushNamed(context, '/favorites'),
            ),
            IconButton(
              icon: const Icon(Icons.casino, color: Colors.white),
              onPressed: () => Navigator.pushNamed(context, '/random'),
            ),
            IconButton(
              icon: const Icon(Icons.logout, color: Colors.white),
              onPressed: () => AuthService().logout(context),
            ),
          ],
        ),
        body: JokeTypeGrid(jokeTypes: jokeTypes),
      ),
    );
  }
}
