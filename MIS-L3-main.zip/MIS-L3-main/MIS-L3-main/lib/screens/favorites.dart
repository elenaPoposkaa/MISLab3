import 'package:flutter/material.dart';
import '../models/joke_model.dart';
import '../services/favorite_service.dart';
import '../widgets/joke_card.dart';
import '../widgets/auth_guard.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AuthGuard(
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "Favorite Jokes",
            style: TextStyle(
              color: Colors.black,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.amber,
          elevation: 4.0,
        ),
        body: StreamBuilder<List<Joke>>(
          stream: FavoriteService().getFavorites(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return const Center(
                child: Text(
                  'Something went wrong',
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 18,
                  ),
                ),
              );
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(
                  color: Colors.amber,
                ),
              );
            }

            final jokes = snapshot.data ?? [];

            if (jokes.isEmpty) {
              return const Center(
                child: Text(
                  'No favorite jokes yet',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 18,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              );
            }

            return ListView.builder(
              itemCount: jokes.length,
              itemBuilder: (context, index) => JokeCard(
                joke: jokes[index],
                isFavorite: true,
                onFavoritePressed: () =>
                    FavoriteService().removeFavorite(jokes[index].id),
              ),
            );
          },
        ),
      ),
    );
  }
}