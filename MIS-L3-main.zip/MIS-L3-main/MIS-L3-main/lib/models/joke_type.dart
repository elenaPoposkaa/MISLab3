class JokeType {
  String type;

  JokeType({required this.type});

  JokeType.fromJson(String type) : type = type;
}